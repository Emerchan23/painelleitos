"use client"

import { useState } from "react"
import { HospitalProvider, useHospital, type Bed } from "@/lib/hospital-context"
import { PatientInterface } from "@/components/patient-interface"
import { NursingDashboard } from "@/components/nursing-dashboard"
import { AdminDashboard } from "@/components/admin-dashboard"
import { LoginForm } from "@/components/login-form"
import { BedDouble, LayoutDashboard, HeartPulse, ChevronRight, Settings, Lock } from "lucide-react"
import { cn } from "@/lib/utils"

type ViewMode = "menu" | "patient" | "nursing" | "admin" | "login"

function HospitalApp() {
  const { beds, getOccupiedBeds, isAuthenticated, logout } = useHospital()
  const [viewMode, setViewMode] = useState<ViewMode>("menu")
  const [selectedBed, setSelectedBed] = useState<Bed | null>(null)

  const occupiedBeds = getOccupiedBeds()

  const handleSelectBed = (bed: Bed) => {
    setSelectedBed(bed)
    setViewMode("patient")
  }

  const handleAdminAccess = () => {
    if (isAuthenticated) {
      setViewMode("admin")
    } else {
      setViewMode("login")
    }
  }

  const handleLoginSuccess = () => {
    setViewMode("admin")
  }

  const handleBackToMenu = () => {
    setViewMode("menu")
  }

  return (
    <>
      {viewMode === "menu" && (
        <MainMenu 
          onSelectNursing={() => setViewMode("nursing")}
          onSelectAdmin={handleAdminAccess}
          onSelectBed={handleSelectBed}
          beds={occupiedBeds}
        />
      )}
      
      {viewMode === "patient" && selectedBed && (
        <div className="relative">
          <button
            onClick={handleBackToMenu}
            className="fixed top-4 left-4 z-50 bg-card/80 backdrop-blur border border-border px-3 py-2 rounded-lg text-sm text-foreground hover:bg-card transition-colors"
          >
            Voltar
          </button>
          <PatientInterface 
            bedNumber={selectedBed.number} 
            patientName={selectedBed.patientName || "Paciente"} 
            ward={selectedBed.ward}
          />
        </div>
      )}
      
      {viewMode === "nursing" && (
        <div className="relative">
          <button
            onClick={handleBackToMenu}
            className="fixed top-4 left-4 z-50 bg-card/80 backdrop-blur border border-border px-3 py-2 rounded-lg text-sm text-foreground hover:bg-card transition-colors"
          >
            Voltar
          </button>
          <NursingDashboard />
        </div>
      )}

      {viewMode === "login" && (
        <div className="relative">
          <button
            onClick={handleBackToMenu}
            className="fixed top-4 left-4 z-50 bg-card/80 backdrop-blur border border-border px-3 py-2 rounded-lg text-sm text-foreground hover:bg-card transition-colors"
          >
            Voltar
          </button>
          <LoginForm onSuccess={handleLoginSuccess} />
        </div>
      )}
      
      {viewMode === "admin" && (
        <div className="relative">
          <button
            onClick={() => {
              logout()
              handleBackToMenu()
            }}
            className="fixed top-4 left-4 z-50 bg-card/80 backdrop-blur border border-border px-3 py-2 rounded-lg text-sm text-foreground hover:bg-card transition-colors"
          >
            Voltar ao Menu
          </button>
          <AdminDashboard />
        </div>
      )}
    </>
  )
}

export default function HospitalCallSystem() {
  return (
    <HospitalProvider>
      <HospitalApp />
    </HospitalProvider>
  )
}

function MainMenu({ 
  onSelectNursing,
  onSelectAdmin,
  onSelectBed,
  beds 
}: { 
  onSelectNursing: () => void
  onSelectAdmin: () => void
  onSelectBed: (bed: Bed) => void
  beds: Bed[]
}) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4">
            <div className="bg-primary p-3 rounded-xl">
              <HeartPulse className="h-8 w-8 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Chamado Digital</h1>
              <p className="text-muted-foreground">Sistema de Leitos Hospitalares</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {/* Nursing Dashboard Card - No Auth Required */}
          <button
            onClick={onSelectNursing}
            className={cn(
              "bg-card rounded-2xl border border-border p-6 text-left",
              "hover:border-primary hover:shadow-lg transition-all",
              "group"
            )}
          >
            <div className="bg-primary/10 w-16 h-16 rounded-xl flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
              <LayoutDashboard className="h-8 w-8 text-primary" />
            </div>
            <h2 className="text-xl font-semibold text-foreground mb-2">Central de Enfermagem</h2>
            <p className="text-muted-foreground text-sm mb-4">
              Painel para TV/Monitor grande. Visualize e gerencie todos os chamados em tempo real com alertas sonoros.
            </p>
            <div className="flex items-center text-primary text-sm font-medium">
              Acessar painel
              <ChevronRight className="h-4 w-4 ml-1 group-hover:translate-x-1 transition-transform" />
            </div>
          </button>

          {/* Admin Dashboard Card - Auth Required */}
          <button
            onClick={onSelectAdmin}
            className={cn(
              "bg-card rounded-2xl border border-border p-6 text-left",
              "hover:border-success hover:shadow-lg transition-all",
              "group"
            )}
          >
            <div className="bg-success/10 w-16 h-16 rounded-xl flex items-center justify-center mb-4 group-hover:bg-success/20 transition-colors">
              <Settings className="h-8 w-8 text-success" />
            </div>
            <div className="flex items-center gap-2 mb-2">
              <h2 className="text-xl font-semibold text-foreground">Painel Administrativo</h2>
              <Lock className="h-4 w-4 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground text-sm mb-4">
              Cadastre leitos, gerencie usuários, configure alertas sonoros e acompanhe relatórios de SLA.
            </p>
            <div className="flex items-center text-success text-sm font-medium">
              Fazer login
              <ChevronRight className="h-4 w-4 ml-1 group-hover:translate-x-1 transition-transform" />
            </div>
          </button>

          {/* Patient Interface Card */}
          <div className="bg-card rounded-2xl border border-border p-6">
            <div className="bg-routine/10 w-16 h-16 rounded-xl flex items-center justify-center mb-4">
              <BedDouble className="h-8 w-8 text-routine" />
            </div>
            <h2 className="text-xl font-semibold text-foreground mb-2">Interface do Paciente</h2>
            <p className="text-muted-foreground text-sm mb-4">
              Selecione um leito ocupado para simular a interface do paciente.
            </p>
            
            <div className="space-y-2 max-h-[200px] overflow-y-auto">
              {beds.length === 0 ? (
                <p className="text-sm text-muted-foreground py-4 text-center">
                  Nenhum leito ocupado no momento
                </p>
              ) : (
                beds.slice(0, 5).map((bed) => (
                  <button
                    key={bed.id}
                    onClick={() => onSelectBed(bed)}
                    className={cn(
                      "w-full flex items-center justify-between p-3 rounded-lg",
                      "bg-secondary hover:bg-secondary/80 transition-colors",
                      "group"
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <div className="bg-routine/20 w-10 h-10 rounded-lg flex items-center justify-center">
                        <BedDouble className="h-5 w-5 text-routine" />
                      </div>
                      <div className="text-left">
                        <p className="font-medium text-foreground">Leito {bed.number}</p>
                        <p className="text-xs text-muted-foreground">{bed.patientName} - {bed.ward}</p>
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:translate-x-1 transition-transform" />
                  </button>
                ))
              )}
              {beds.length > 5 && (
                <p className="text-xs text-muted-foreground text-center pt-2">
                  +{beds.length - 5} leitos ocupados
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="max-w-5xl mx-auto mt-8">
          <div className="bg-muted/50 rounded-xl p-6">
            <h3 className="font-semibold text-foreground mb-3">Como funciona o sistema:</h3>
            <ol className="space-y-2 text-sm text-muted-foreground list-decimal list-inside">
              <li>
                <strong className="text-foreground">Central de Enfermagem:</strong> Exiba em uma TV/Monitor grande. Acesso livre, sem necessidade de login. Sons de alerta automáticos.
              </li>
              <li>
                <strong className="text-foreground">Painel Administrativo:</strong> Acesso restrito por login. Cadastre leitos, usuários e configure sons de alerta.
              </li>
              <li>
                <strong className="text-foreground">Paciente:</strong> Utiliza a interface no tablet para fazer solicitações (emergência, dor, higiene, água, ajuste de leito)
              </li>
              <li>
                <strong className="text-foreground">Prioridades:</strong> Vermelho (Crítico) - som alto e repetido, Amarelo (Urgente), Azul (Rotina)
              </li>
            </ol>
          </div>
        </div>

        {/* Credentials Info */}
        <div className="max-w-5xl mx-auto mt-4">
          <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
            <p className="text-sm text-center text-muted-foreground">
              <strong className="text-foreground">Credenciais padrão do administrador:</strong> admin@hospital.com / admin123
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-auto">
        <div className="container mx-auto px-4 py-4 text-center">
          <p className="text-sm text-muted-foreground">
            Sistema de Chamado Digital de Leitos Hospitalares
          </p>
        </div>
      </footer>
    </div>
  )
}
