"use client"

import { use } from "react"
import { PatientInterface } from "@/components/patient-interface"
import { HospitalProvider, useHospital } from "@/lib/hospital-context"
import { ArrowLeft, AlertCircle } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

function BedPage({ bedId }: { bedId: string }) {
  const { beds } = useHospital()
  
  const bed = beds.find((b) => b.id === bedId)
  
  if (!bed) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="text-center space-y-4">
          <div className="bg-destructive/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
            <AlertCircle className="h-8 w-8 text-destructive" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Leito não encontrado</h1>
          <p className="text-muted-foreground max-w-md">
            O leito solicitado não existe ou foi removido do sistema. 
            Entre em contato com a administração.
          </p>
          <Link href="/">
            <Button variant="outline">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar ao Início
            </Button>
          </Link>
        </div>
      </div>
    )
  }
  
  if (bed.status !== "occupied") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="text-center space-y-4">
          <div className="bg-urgent/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
            <AlertCircle className="h-8 w-8 text-urgent" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Leito {bed.number}</h1>
          <p className="text-muted-foreground max-w-md">
            Este leito está atualmente{" "}
            {bed.status === "available" ? "disponível" : 
             bed.status === "maintenance" ? "em manutenção" : "reservado"}.
            A interface do paciente está disponível apenas para leitos ocupados.
          </p>
          <Link href="/">
            <Button variant="outline">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar ao Início
            </Button>
          </Link>
        </div>
      </div>
    )
  }
  
  return (
    <div className="relative">
      <Link 
        href="/"
        className="fixed top-4 left-4 z-50 bg-card/80 backdrop-blur border border-border px-3 py-2 rounded-lg text-sm text-foreground hover:bg-card transition-colors"
      >
        ← Voltar
      </Link>
      <PatientInterface 
        bedNumber={bed.number} 
        patientName={bed.patientName || "Paciente"} 
        ward={bed.ward}
      />
    </div>
  )
}

export default function LeitoPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  
  return (
    <HospitalProvider>
      <BedPage bedId={id} />
    </HospitalProvider>
  )
}
