import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { v4 as uuidv4 } from 'uuid'
import { query, queryOne, execute } from '@/lib/db'
import type { DBAdminUser, DBSession, LoginRequest, ApiResponse, AdminUser } from '@/lib/types'

export async function POST(request: NextRequest) {
  try {
    const body: LoginRequest = await request.json()
    const { email, password } = body

    if (!email || !password) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Email e senha são obrigatórios' },
        { status: 400 }
      )
    }

    // Buscar usuário pelo email
    const user = await queryOne<DBAdminUser>(
      'SELECT * FROM admin_users WHERE email = ?',
      [email]
    )

    if (!user) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Credenciais inválidas' },
        { status: 401 }
      )
    }

    // Verificar senha
    const isValidPassword = await bcrypt.compare(password, user.password)
    
    // Para desenvolvimento, também aceitar senha em texto plano (remover em produção)
    const isPlainTextMatch = password === user.password

    if (!isValidPassword && !isPlainTextMatch) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Credenciais inválidas' },
        { status: 401 }
      )
    }

    // Criar token de sessão
    const token = uuidv4()
    const sessionId = uuidv4()
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 horas

    // Salvar sessão no banco
    await execute(
      'INSERT INTO sessions (id, user_id, token, expires_at) VALUES (?, ?, ?, ?)',
      [sessionId, user.id, token, expiresAt]
    )

    const adminUser: AdminUser = {
      id: user.id,
      name: user.name,
      email: user.email,
      createdAt: user.created_at,
    }

    // Criar resposta com cookie
    const response = NextResponse.json<ApiResponse<{ user: AdminUser; token: string }>>(
      {
        success: true,
        data: { user: adminUser, token },
        message: 'Login realizado com sucesso',
      },
      { status: 200 }
    )

    // Definir cookie httpOnly
    response.cookies.set('session_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 24 * 60 * 60, // 24 horas
      path: '/',
    })

    return response
  } catch (error) {
    console.error('Erro no login:', error)
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}
