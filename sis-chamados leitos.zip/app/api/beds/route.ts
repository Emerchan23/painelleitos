import { NextRequest, NextResponse } from 'next/server'
import { v4 as uuidv4 } from 'uuid'
import { query, queryOne, execute } from '@/lib/db'
import type { DBBed, ApiResponse, Bed, CreateBedRequest } from '@/lib/types'

// Converter DB para API format
function mapDBBedToBed(dbBed: DBBed): Bed {
  return {
    id: dbBed.id,
    number: dbBed.number,
    ward: dbBed.ward,
    room: dbBed.room,
    status: dbBed.status,
    patientName: dbBed.patient_name || undefined,
    createdAt: dbBed.created_at,
    updatedAt: dbBed.updated_at,
  }
}

// GET - Listar todos os leitos
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const ward = searchParams.get('ward')
    const status = searchParams.get('status')

    let sql = 'SELECT * FROM beds'
    const conditions: string[] = []
    const params: unknown[] = []

    if (ward) {
      conditions.push('ward = ?')
      params.push(ward)
    }
    if (status) {
      conditions.push('status = ?')
      params.push(status)
    }

    if (conditions.length > 0) {
      sql += ' WHERE ' + conditions.join(' AND ')
    }

    sql += ' ORDER BY ward, number'

    const beds = await query<DBBed>(sql, params)

    return NextResponse.json<ApiResponse<{ beds: Bed[] }>>(
      {
        success: true,
        data: { beds: beds.map(mapDBBedToBed) },
      },
      { status: 200 }
    )
  } catch (error) {
    console.error('Erro ao listar leitos:', error)
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}

// POST - Criar novo leito
export async function POST(request: NextRequest) {
  try {
    const body: CreateBedRequest = await request.json()
    const { number, ward, room, status = 'available', patientName } = body

    if (!number || !ward || !room) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Número, ala e quarto são obrigatórios' },
        { status: 400 }
      )
    }

    // Verificar se número do leito já existe
    const existingBed = await queryOne<DBBed>(
      'SELECT id FROM beds WHERE number = ?',
      [number]
    )

    if (existingBed) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Já existe um leito com este número' },
        { status: 400 }
      )
    }

    const bedId = uuidv4()

    await execute(
      `INSERT INTO beds (id, number, ward, room, status, patient_name) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [bedId, number, ward, room, status, patientName || null]
    )

    const newBed: Bed = {
      id: bedId,
      number,
      ward,
      room,
      status,
      patientName: patientName || undefined,
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    return NextResponse.json<ApiResponse<{ bed: Bed }>>(
      {
        success: true,
        data: { bed: newBed },
        message: 'Leito criado com sucesso',
      },
      { status: 201 }
    )
  } catch (error) {
    console.error('Erro ao criar leito:', error)
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}
