import { NextRequest, NextResponse } from 'next/server'
import { v4 as uuidv4 } from 'uuid'
import { query, queryOne, execute } from '@/lib/db'
import type { DBCall, DBBed, ApiResponse, BedCall, CreateCallRequest, CallPriority, CallType } from '@/lib/types'

// Mapeamento de tipo de chamado para prioridade
const CALL_TYPE_PRIORITY: Record<CallType, CallPriority> = {
  emergency: 'emergency',
  pain: 'urgent',
  hygiene: 'routine',
  water: 'routine',
  bed: 'routine',
}

// Converter DB para API format
function mapDBCallToBedCall(dbCall: DBCall): BedCall {
  return {
    id: dbCall.id,
    bedId: dbCall.bed_id,
    bedNumber: dbCall.bed_number,
    patientName: dbCall.patient_name,
    callType: dbCall.call_type,
    priority: dbCall.priority,
    status: dbCall.status,
    ward: dbCall.ward || undefined,
    createdAt: dbCall.created_at,
    seenAt: dbCall.seen_at || undefined,
    attendingAt: dbCall.attending_at || undefined,
    completedAt: dbCall.completed_at || undefined,
  }
}

// GET - Listar chamados
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const priority = searchParams.get('priority')
    const ward = searchParams.get('ward')
    const bedNumber = searchParams.get('bedNumber')
    const active = searchParams.get('active') // 'true' para chamados não completados

    let sql = 'SELECT * FROM calls'
    const conditions: string[] = []
    const params: unknown[] = []

    if (active === 'true') {
      conditions.push("status != 'completed'")
    }
    if (status) {
      conditions.push('status = ?')
      params.push(status)
    }
    if (priority) {
      conditions.push('priority = ?')
      params.push(priority)
    }
    if (ward) {
      conditions.push('ward = ?')
      params.push(ward)
    }
    if (bedNumber) {
      conditions.push('bed_number = ?')
      params.push(bedNumber)
    }

    if (conditions.length > 0) {
      sql += ' WHERE ' + conditions.join(' AND ')
    }

    // Ordenar por prioridade e data de criação
    sql += ` ORDER BY 
      FIELD(priority, 'emergency', 'urgent', 'routine'),
      created_at ASC`

    const calls = await query<DBCall>(sql, params)

    return NextResponse.json<ApiResponse<{ calls: BedCall[] }>>(
      {
        success: true,
        data: { calls: calls.map(mapDBCallToBedCall) },
      },
      { status: 200 }
    )
  } catch (error) {
    console.error('Erro ao listar chamados:', error)
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}

// POST - Criar novo chamado
export async function POST(request: NextRequest) {
  try {
    const body: CreateCallRequest = await request.json()
    const { bedNumber, patientName, callType, ward } = body

    if (!bedNumber || !patientName || !callType) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Número do leito, nome do paciente e tipo de chamado são obrigatórios' },
        { status: 400 }
      )
    }

    // Buscar ID do leito
    const bed = await queryOne<DBBed>(
      'SELECT id, ward FROM beds WHERE number = ?',
      [bedNumber]
    )

    if (!bed) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Leito não encontrado' },
        { status: 404 }
      )
    }

    // Verificar se já existe chamado ativo do mesmo tipo para este leito
    const existingCall = await queryOne<DBCall>(
      `SELECT id FROM calls 
       WHERE bed_number = ? AND call_type = ? AND status != 'completed'`,
      [bedNumber, callType]
    )

    if (existingCall) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Já existe um chamado ativo deste tipo para este leito' },
        { status: 400 }
      )
    }

    const callId = uuidv4()
    const priority = CALL_TYPE_PRIORITY[callType] || 'routine'
    const callWard = ward || bed.ward

    await execute(
      `INSERT INTO calls (id, bed_id, bed_number, patient_name, call_type, priority, status, ward) 
       VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)`,
      [callId, bed.id, bedNumber, patientName, callType, priority, callWard]
    )

    const newCall: BedCall = {
      id: callId,
      bedId: bed.id,
      bedNumber,
      patientName,
      callType,
      priority,
      status: 'pending',
      ward: callWard,
      createdAt: new Date(),
    }

    return NextResponse.json<ApiResponse<{ call: BedCall }>>(
      {
        success: true,
        data: { call: newCall },
        message: 'Chamado criado com sucesso',
      },
      { status: 201 }
    )
  } catch (error) {
    console.error('Erro ao criar chamado:', error)
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}
