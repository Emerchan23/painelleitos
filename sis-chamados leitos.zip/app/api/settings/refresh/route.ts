import { NextRequest, NextResponse } from 'next/server'
import { queryOne, execute } from '@/lib/db'
import type { DBRefreshSettings, ApiResponse, RefreshSettings } from '@/lib/types'

// Converter DB para API format
function mapDBToRefreshSettings(db: DBRefreshSettings): RefreshSettings {
  return {
    enabled: db.enabled,
    intervalSeconds: db.interval_seconds,
    timezone: db.timezone,
  }
}

// GET - Buscar configurações de atualização
export async function GET() {
  try {
    let settings = await queryOne<DBRefreshSettings>(
      'SELECT * FROM refresh_settings WHERE id = ?',
      ['default']
    )

    // Se não existir, criar configuração padrão
    if (!settings) {
      await execute(
        `INSERT INTO refresh_settings (id, enabled, interval_seconds, timezone)
         VALUES ('default', TRUE, 30, 'America/Sao_Paulo')`
      )
      
      settings = await queryOne<DBRefreshSettings>(
        'SELECT * FROM refresh_settings WHERE id = ?',
        ['default']
      )
    }

    return NextResponse.json<ApiResponse<{ settings: RefreshSettings }>>(
      {
        success: true,
        data: { settings: mapDBToRefreshSettings(settings!) },
      },
      { status: 200 }
    )
  } catch (error) {
    console.error('Erro ao buscar configurações de atualização:', error)
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}

// PUT - Atualizar configurações de atualização
export async function PUT(request: NextRequest) {
  try {
    const body: Partial<RefreshSettings> = await request.json()
    const { enabled, intervalSeconds, timezone } = body

    const updates: string[] = []
    const values: unknown[] = []

    if (enabled !== undefined) {
      updates.push('enabled = ?')
      values.push(enabled)
    }
    if (intervalSeconds !== undefined) {
      updates.push('interval_seconds = ?')
      values.push(intervalSeconds)
    }
    if (timezone !== undefined) {
      updates.push('timezone = ?')
      values.push(timezone)
    }

    if (updates.length === 0) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Nenhum campo para atualizar' },
        { status: 400 }
      )
    }

    await execute(
      `UPDATE refresh_settings SET ${updates.join(', ')} WHERE id = 'default'`,
      values
    )

    const updatedSettings = await queryOne<DBRefreshSettings>(
      'SELECT * FROM refresh_settings WHERE id = ?',
      ['default']
    )

    return NextResponse.json<ApiResponse<{ settings: RefreshSettings }>>(
      {
        success: true,
        data: { settings: mapDBToRefreshSettings(updatedSettings!) },
        message: 'Configurações de atualização atualizadas com sucesso',
      },
      { status: 200 }
    )
  } catch (error) {
    console.error('Erro ao atualizar configurações de atualização:', error)
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}
