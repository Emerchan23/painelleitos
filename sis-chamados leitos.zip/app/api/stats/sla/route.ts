import { NextResponse } from 'next/server'
import { query } from '@/lib/db'
import type { ApiResponse, SLAStats, WardType } from '@/lib/types'

interface DBSLAStats {
  ward: WardType
  total_calls: number
  avg_response_seconds: number | null
  min_response_seconds: number | null
  max_response_seconds: number | null
}

// GET - Buscar estatísticas de SLA por ala
export async function GET() {
  try {
    const stats = await query<DBSLAStats>(`
      SELECT 
        ward,
        COUNT(*) as total_calls,
        AVG(TIMESTAMPDIFF(SECOND, created_at, completed_at)) as avg_response_seconds,
        MIN(TIMESTAMPDIFF(SECOND, created_at, completed_at)) as min_response_seconds,
        MAX(TIMESTAMPDIFF(SECOND, created_at, completed_at)) as max_response_seconds
      FROM calls
      WHERE status = 'completed' AND completed_at IS NOT NULL AND ward IS NOT NULL
      GROUP BY ward
    `)

    // Garantir que todas as alas estejam representadas
    const allWards: WardType[] = ['UTI', 'Enfermaria', 'Pediatria', 'Maternidade', 'Emergência']
    
    const slaStats: SLAStats[] = allWards.map((ward) => {
      const wardStats = stats.find((s) => s.ward === ward)
      return {
        ward,
        totalCalls: wardStats?.total_calls || 0,
        avgResponseSeconds: wardStats?.avg_response_seconds || 0,
        minResponseSeconds: wardStats?.min_response_seconds || 0,
        maxResponseSeconds: wardStats?.max_response_seconds || 0,
      }
    })

    return NextResponse.json<ApiResponse<{ stats: SLAStats[] }>>(
      {
        success: true,
        data: { stats: slaStats },
      },
      { status: 200 }
    )
  } catch (error) {
    console.error('Erro ao buscar estatísticas de SLA:', error)
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}
