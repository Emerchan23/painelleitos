"use client"

import { useState, useMemo } from "react"
import { useHospital, Bed, WardType } from "@/lib/hospital-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Field, FieldGroup, FieldLabel } from "@/components/ui/field"
import { 
  BedDouble, 
  Plus, 
  Pencil, 
  Trash2, 
  Building2, 
  Clock,
  BarChart3,
  Link2,
  LogOut,
  Users,
  Volume2,
  Settings
} from "lucide-react"
import { cn } from "@/lib/utils"
import { UserManagement } from "./user-management"
import { SoundSettings } from "./sound-settings"
import { RefreshSettings } from "./refresh-settings"

const WARD_OPTIONS: WardType[] = ["UTI", "Enfermaria", "Pediatria", "Maternidade", "Emergência"]

function formatTime(ms: number): string {
  const minutes = Math.floor(ms / 60000)
  if (minutes < 60) return `${minutes} min`
  const hours = Math.floor(minutes / 60)
  const remainingMinutes = minutes % 60
  return `${hours}h ${remainingMinutes}min`
}

export function AdminDashboard() {
  const { beds, addBed, updateBed, deleteBed, getSLAByWard, logout, currentUser } = useHospital()
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingBed, setEditingBed] = useState<Bed | null>(null)
  const [deleteConfirmBed, setDeleteConfirmBed] = useState<Bed | null>(null)
  
  // Form state
  const [formData, setFormData] = useState({
    number: "",
    ward: "Enfermaria" as WardType,
    room: "",
  })

  const slaStats = getSLAByWard()

  const bedsByWard = useMemo(() => {
    const grouped: Record<WardType, Bed[]> = {
      UTI: [],
      Enfermaria: [],
      Pediatria: [],
      Maternidade: [],
      Emergência: [],
    }
    beds.forEach((bed) => {
      grouped[bed.ward].push(bed)
    })
    return grouped
  }, [beds])

  const stats = useMemo(() => {
    const total = beds.length
    return { total }
  }, [beds])

  const handleOpenDialog = (bed?: Bed) => {
    if (bed) {
      setEditingBed(bed)
      setFormData({
        number: bed.number,
        ward: bed.ward,
        room: bed.room,
      })
    } else {
      setEditingBed(null)
      setFormData({
        number: "",
        ward: "Enfermaria",
        room: "",
      })
    }
    setIsDialogOpen(true)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (editingBed) {
      updateBed(editingBed.id, {
        number: formData.number,
        ward: formData.ward,
        room: formData.room,
      })
    } else {
      addBed({
        number: formData.number,
        ward: formData.ward,
        room: formData.room,
        status: "available",
      })
    }
    setIsDialogOpen(false)
    setEditingBed(null)
  }

  const handleDelete = () => {
    if (deleteConfirmBed) {
      deleteBed(deleteConfirmBed.id)
      setDeleteConfirmBed(null)
    }
  }

  const getBedLink = (bed: Bed) => {
    return `/leito/${bed.id}`
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-primary p-2 rounded-lg">
                <Building2 className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Painel Administrativo</h1>
                <p className="text-sm text-muted-foreground">Gestão de Leitos</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {currentUser && (
                <span className="text-sm text-muted-foreground">
                  Olá, {currentUser.name}
                </span>
              )}
              <Button variant="outline" onClick={logout}>
                <LogOut className="h-4 w-4 mr-2" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 max-w-3xl">
            <TabsTrigger value="overview">Visão Geral</TabsTrigger>
            <TabsTrigger value="beds">Leitos</TabsTrigger>
            <TabsTrigger value="sla">Relatório SLA</TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              Usuários
            </TabsTrigger>
            <TabsTrigger value="sounds" className="flex items-center gap-1">
              <Volume2 className="h-4 w-4" />
              Sons
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-1">
              <Settings className="h-4 w-4" />
              Config
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="pt-4">
                  <div className="flex items-center gap-3">
                    <div className="bg-primary/10 p-2 rounded-lg">
                      <BedDouble className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-foreground">{stats.total}</p>
                      <p className="text-xs text-muted-foreground">Total de Leitos</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {WARD_OPTIONS.slice(0, 2).map((ward) => (
                <Card key={ward}>
                  <CardContent className="pt-4">
                    <div className="flex items-center gap-3">
                      <div className="bg-muted p-2 rounded-lg">
                        <Building2 className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-foreground">{bedsByWard[ward].length}</p>
                        <p className="text-xs text-muted-foreground">{ward}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Heat Map */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Mapa de Leitos por Ala</CardTitle>
                <CardDescription>Visualização dos leitos cadastrados em cada ala</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {WARD_OPTIONS.map((ward) => {
                    const wardBeds = bedsByWard[ward]
                    
                    return (
                      <div key={ward} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Building2 className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium text-foreground">{ward}</span>
                            <Badge variant="outline" className="text-xs">
                              {wardBeds.length} leitos
                            </Badge>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-2">
                          {wardBeds.length === 0 ? (
                            <p className="text-sm text-muted-foreground">Nenhum leito cadastrado</p>
                          ) : (
                            wardBeds.map((bed) => (
                              <div
                                key={bed.id}
                                className={cn(
                                  "w-12 h-12 rounded-lg flex flex-col items-center justify-center text-xs font-medium transition-all hover:scale-105 cursor-pointer",
                                  "bg-primary/10 text-primary border border-primary/20"
                                )}
                                title={`Leito ${bed.number} - Quarto ${bed.room}`}
                              >
                                <span>{bed.number}</span>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Beds Tab */}
          <TabsContent value="beds">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base">Lista de Leitos</CardTitle>
                    <CardDescription>Gerencie todos os leitos cadastrados no sistema</CardDescription>
                  </div>
                  <Button onClick={() => handleOpenDialog()}>
                    <Plus className="h-4 w-4 mr-2" />
                    Novo Leito
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border border-border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/50">
                        <TableHead>Leito</TableHead>
                        <TableHead>Ala</TableHead>
                        <TableHead>Quarto</TableHead>
                        <TableHead>Link Tablet</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {beds.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                            Nenhum leito cadastrado
                          </TableCell>
                        </TableRow>
                      ) : (
                        beds.map((bed) => (
                          <TableRow key={bed.id}>
                            <TableCell className="font-medium">{bed.number}</TableCell>
                            <TableCell>{bed.ward}</TableCell>
                            <TableCell>{bed.room}</TableCell>
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 px-2 text-primary hover:text-primary"
                                onClick={() => navigator.clipboard.writeText(window.location.origin + getBedLink(bed))}
                                title="Copiar link do leito"
                              >
                                <Link2 className="h-4 w-4 mr-1" />
                                Copiar
                              </Button>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 w-8 p-0"
                                  onClick={() => handleOpenDialog(bed)}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                                  onClick={() => setDeleteConfirmBed(bed)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* SLA Tab */}
          <TabsContent value="sla">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <BarChart3 className="h-5 w-5" />
                  Relatório de SLA por Ala
                </CardTitle>
                <CardDescription>
                  Tempo médio de atendimento dos chamados por ala hospitalar
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {WARD_OPTIONS.map((ward) => {
                    const wardData = slaStats[ward]
                    const maxTime = Math.max(...Object.values(slaStats).map((s) => s.avgTime), 1)
                    const percentage = maxTime > 0 ? (wardData.avgTime / maxTime) * 100 : 0
                    
                    return (
                      <div key={ward} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Building2 className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium text-foreground">{ward}</span>
                          </div>
                          <div className="flex items-center gap-4">
                            <Badge variant="outline" className="text-xs">
                              {wardData.count} chamados
                            </Badge>
                            <div className="flex items-center gap-1 text-sm">
                              <Clock className="h-4 w-4 text-muted-foreground" />
                              <span className="font-medium text-foreground">
                                {wardData.count > 0 ? formatTime(wardData.avgTime) : "-"}
                              </span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="h-3 bg-muted rounded-full overflow-hidden">
                          <div 
                            className={cn(
                              "h-full transition-all duration-500",
                              wardData.avgTime > 600000 ? "bg-emergency" :
                              wardData.avgTime > 300000 ? "bg-urgent" : "bg-success"
                            )}
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                    )
                  })}

                  {/* SLA Legend */}
                  <div className="flex flex-wrap gap-4 mt-6 pt-4 border-t border-border">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-success" />
                      <span className="text-sm text-muted-foreground">{"< 5 min (Excelente)"}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-urgent" />
                      <span className="text-sm text-muted-foreground">5-10 min (Atenção)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-emergency" />
                      <span className="text-sm text-muted-foreground">{"> 10 min (Crítico)"}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users">
            <UserManagement />
          </TabsContent>

          {/* Sounds Tab */}
          <TabsContent value="sounds">
            <SoundSettings />
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <RefreshSettings />
          </TabsContent>
        </Tabs>
      </main>

      {/* Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingBed ? "Editar Leito" : "Novo Leito"}</DialogTitle>
            <DialogDescription>
              {editingBed ? "Atualize as informações do leito." : "Preencha os dados para cadastrar um novo leito."}
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit}>
            <FieldGroup className="gap-4">
              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <FieldLabel>Número do Leito</FieldLabel>
                  <Input
                    value={formData.number}
                    onChange={(e) => setFormData((prev) => ({ ...prev, number: e.target.value }))}
                    placeholder="Ex: 101"
                    required
                  />
                </Field>
                
                <Field>
                  <FieldLabel>Quarto</FieldLabel>
                  <Input
                    value={formData.room}
                    onChange={(e) => setFormData((prev) => ({ ...prev, room: e.target.value }))}
                    placeholder="Ex: A1"
                    required
                  />
                </Field>
              </div>
              
              <Field>
                <FieldLabel>Ala</FieldLabel>
                <Select
                  value={formData.ward}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, ward: value as WardType }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {WARD_OPTIONS.map((ward) => (
                      <SelectItem key={ward} value={ward}>
                        {ward}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
            </FieldGroup>
            
            <DialogFooter className="mt-6">
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit">
                {editingBed ? "Salvar" : "Cadastrar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!deleteConfirmBed} onOpenChange={() => setDeleteConfirmBed(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar Exclusão</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir o leito {deleteConfirmBed?.number}? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteConfirmBed(null)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
