"use client"

import { useState, useEffect } from "react"
import { useHospital, type CallType, type WardType, getCallTypeLabel } from "@/lib/hospital-context"
import { AlertTriangle, Droplets, Bath, BedDouble, HeartPulse, Check, Eye } from "lucide-react"
import { cn } from "@/lib/utils"

interface PatientInterfaceProps {
  bedNumber: string
  patientName: string
  ward?: WardType
}

const CALL_BUTTONS: { type: CallType; icon: React.ElementType; className: string }[] = [
  {
    type: "emergency",
    icon: AlertTriangle,
    className: "bg-emergency text-emergency-foreground hover:bg-emergency/90",
  },
  {
    type: "pain",
    icon: HeartPulse,
    className: "bg-urgent text-urgent-foreground hover:bg-urgent/90",
  },
  {
    type: "hygiene",
    icon: Bath,
    className: "bg-routine text-routine-foreground hover:bg-routine/90",
  },
  {
    type: "water",
    icon: Droplets,
    className: "bg-routine text-routine-foreground hover:bg-routine/90",
  },
  {
    type: "bed",
    icon: BedDouble,
    className: "bg-routine text-routine-foreground hover:bg-routine/90",
  },
]

export function PatientInterface({ bedNumber, patientName, ward }: PatientInterfaceProps) {
  const { createCall, getCallsForBed } = useHospital()
  const [feedbackType, setFeedbackType] = useState<CallType | null>(null)
  const [activeCalls, setActiveCalls] = useState<ReturnType<typeof getCallsForBed>>([])

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveCalls(getCallsForBed(bedNumber))
    }, 500)
    return () => clearInterval(interval)
  }, [bedNumber, getCallsForBed])

  const handleCall = (type: CallType) => {
    // Check if there's already an active call of this type
    const existingCall = activeCalls.find((call) => call.callType === type)
    if (existingCall) return

    createCall(bedNumber, patientName, type, ward)
    setFeedbackType(type)
    setTimeout(() => setFeedbackType(null), 3000)
  }

  const getCallStatus = (type: CallType) => {
    return activeCalls.find((call) => call.callType === type)
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="bg-card border-b border-border p-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-semibold text-foreground">Leito {bedNumber}</h1>
            <p className="text-sm text-muted-foreground">{patientName}</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-success animate-pulse" />
            <span className="text-sm text-muted-foreground">Conectado</span>
          </div>
        </div>
      </header>

      {/* Feedback Toast */}
      {feedbackType && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-4">
          <div className="bg-success text-success-foreground px-6 py-3 rounded-lg shadow-lg flex items-center gap-3">
            <Check className="h-5 w-5" />
            <span className="font-medium">Chamado enviado: {getCallTypeLabel(feedbackType)}</span>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 p-4 flex flex-col gap-4">
        {/* Emergency Button */}
        <button
          onClick={() => handleCall("emergency")}
          disabled={!!getCallStatus("emergency")}
          className={cn(
            "relative w-full py-8 rounded-2xl text-2xl font-bold transition-all",
            "flex flex-col items-center justify-center gap-3",
            "shadow-lg active:scale-[0.98]",
            "bg-emergency text-emergency-foreground hover:bg-emergency/90",
            "disabled:opacity-70 disabled:cursor-not-allowed"
          )}
        >
          <AlertTriangle className="h-16 w-16" />
          <span>EMERGÊNCIA / SOS</span>
          {getCallStatus("emergency") && (
            <CallStatusBadge status={getCallStatus("emergency")!.status} />
          )}
        </button>

        {/* Other Buttons Grid */}
        <div className="grid grid-cols-2 gap-4 flex-1">
          {CALL_BUTTONS.slice(1).map(({ type, icon: Icon, className }) => {
            const callStatus = getCallStatus(type)
            return (
              <button
                key={type}
                onClick={() => handleCall(type)}
                disabled={!!callStatus}
                className={cn(
                  "relative rounded-2xl text-xl font-semibold transition-all",
                  "flex flex-col items-center justify-center gap-3",
                  "shadow-md active:scale-[0.98] min-h-[140px]",
                  className,
                  "disabled:opacity-70 disabled:cursor-not-allowed"
                )}
              >
                <Icon className="h-12 w-12" />
                <span>{getCallTypeLabel(type)}</span>
                {callStatus && <CallStatusBadge status={callStatus.status} />}
              </button>
            )
          })}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border p-4 text-center">
        <p className="text-sm text-muted-foreground">
          Pressione um botão para solicitar assistência
        </p>
      </footer>
    </div>
  )
}

function CallStatusBadge({ status }: { status: string }) {
  const statusConfig = {
    pending: { label: "Enviado", icon: Check, className: "bg-card/90 text-foreground" },
    seen: { label: "Visualizado", icon: Eye, className: "bg-success/90 text-success-foreground" },
    attending: { label: "Em atendimento", icon: HeartPulse, className: "bg-success text-success-foreground" },
  }

  const config = statusConfig[status as keyof typeof statusConfig]
  if (!config) return null

  return (
    <div
      className={cn(
        "absolute top-2 right-2 px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1",
        config.className
      )}
    >
      <config.icon className="h-3 w-3" />
      {config.label}
    </div>
  )
}
