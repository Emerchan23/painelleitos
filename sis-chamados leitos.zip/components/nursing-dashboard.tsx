"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { useHospital, type BedCall, type CallPriority, getCallTypeLabel } from "@/lib/hospital-context"
import { 
  AlertTriangle, 
  Droplets, 
  Bath, 
  BedDouble, 
  HeartPulse, 
  Clock, 
  Play, 
  CheckCircle2,
  Bell,
  Eye,
  Maximize,
  Volume2,
  VolumeX,
  RefreshCw
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

const CALL_ICONS: Record<string, React.ElementType> = {
  emergency: AlertTriangle,
  pain: HeartPulse,
  hygiene: Bath,
  water: Droplets,
  bed: BedDouble,
}

const PRIORITY_CONFIG: Record<CallPriority, { label: string; className: string }> = {
  emergency: { label: "Crítico", className: "bg-emergency text-emergency-foreground" },
  urgent: { label: "Urgente", className: "bg-urgent text-urgent-foreground" },
  routine: { label: "Rotina", className: "bg-routine text-routine-foreground" },
}

export function NursingDashboard() {
  const { calls, markAsSeen, attendCall, completeCall, hasNewCalls, setHasNewCalls, soundSettings, playAlertSound, refreshSettings } = useHospital()
  const [now, setNow] = useState(new Date())
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [lastRefresh, setLastRefresh] = useState(new Date())
  const [isRefreshing, setIsRefreshing] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)
  const lastCallIdRef = useRef<string | null>(null)

  // Update timer every second
  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(interval)
  }, [])

  // Manual refresh function
  const handleManualRefresh = useCallback(() => {
    setIsRefreshing(true)
    setLastRefresh(new Date())
    // Simulate refresh animation
    setTimeout(() => setIsRefreshing(false), 500)
  }, [])

  // Auto-refresh based on settings
  useEffect(() => {
    if (!refreshSettings.enabled) return
    
    const interval = setInterval(() => {
      setLastRefresh(new Date())
      setIsRefreshing(true)
      setTimeout(() => setIsRefreshing(false), 500)
    }, refreshSettings.intervalSeconds * 1000)

    return () => clearInterval(interval)
  }, [refreshSettings.enabled, refreshSettings.intervalSeconds])

  // Clear new calls notification when viewing
  useEffect(() => {
    if (hasNewCalls) {
      const timeout = setTimeout(() => setHasNewCalls(false), 2000)
      return () => clearTimeout(timeout)
    }
  }, [hasNewCalls, setHasNewCalls])

  // Sort calls by priority and time
  const activeCalls = calls
    .filter((call) => call.status !== "completed")
    .sort((a, b) => {
      const priorityOrder: Record<CallPriority, number> = { emergency: 0, urgent: 1, routine: 2 }
      const priorityDiff = priorityOrder[a.priority] - priorityOrder[b.priority]
      if (priorityDiff !== 0) return priorityDiff
      return a.createdAt.getTime() - b.createdAt.getTime()
    })

  const completedCalls = calls
    .filter((call) => call.status === "completed")
    .sort((a, b) => (b.completedAt?.getTime() || 0) - (a.completedAt?.getTime() || 0))
    .slice(0, 5)

  const stats = {
    total: activeCalls.length,
    emergency: activeCalls.filter((c) => c.priority === "emergency").length,
    urgent: activeCalls.filter((c) => c.priority === "urgent").length,
    routine: activeCalls.filter((c) => c.priority === "routine").length,
  }

  // Play sound for new pending calls
  useEffect(() => {
    const pendingCalls = activeCalls.filter((c) => c.status === "pending")
    if (pendingCalls.length > 0 && soundEnabled) {
      const newestCall = pendingCalls[pendingCalls.length - 1]
      if (newestCall.id !== lastCallIdRef.current) {
        lastCallIdRef.current = newestCall.id
        // Sound is played by the context when call is created
      }
    }
  }, [activeCalls, soundEnabled])

  // Repeat sounds for pending calls based on priority
  useEffect(() => {
    if (!soundEnabled || !soundSettings.enabled) return
    
    const pendingCalls = activeCalls.filter((c) => c.status === "pending")
    if (pendingCalls.length === 0) return

    // Get highest priority pending call
    const highestPriority = pendingCalls.reduce((highest, call) => {
      const priorityOrder: Record<CallPriority, number> = { emergency: 0, urgent: 1, routine: 2 }
      return priorityOrder[call.priority] < priorityOrder[highest.priority] ? call : highest
    }, pendingCalls[0])

    const interval = setInterval(() => {
      playAlertSound(highestPriority.priority)
    }, soundSettings.repeatIntervalSeconds * 1000) // Use configurable interval

    return () => clearInterval(interval)
  }, [activeCalls, soundEnabled, soundSettings.enabled, soundSettings.repeatIntervalSeconds, playAlertSound])

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen()
      setIsFullscreen(true)
    } else {
      document.exitFullscreen()
      setIsFullscreen(false)
    }
  }

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }
    document.addEventListener("fullscreenchange", handleFullscreenChange)
    return () => document.removeEventListener("fullscreenchange", handleFullscreenChange)
  }, [])

  return (
    <div ref={containerRef} className="min-h-screen bg-background flex flex-col">
      {/* Header - Compact for TV */}
      <header className="bg-card border-b border-border sticky top-0 z-40">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-primary p-2 rounded-lg">
                <HeartPulse className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Central de Enfermagem</h1>
                <p className="text-sm text-muted-foreground">Painel de Chamados</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {/* Auto-refresh indicator */}
              <Button
                variant="outline"
                size="sm"
                onClick={handleManualRefresh}
                className="h-auto px-3 py-2 gap-2"
                title="Atualizar agora"
              >
                <RefreshCw className={cn("h-4 w-4", isRefreshing && "animate-spin text-primary")} />
                <div className="text-xs text-left">
                  <p className="font-medium">
                    {refreshSettings.enabled ? `Auto: ${refreshSettings.intervalSeconds}s` : "Manual"}
                  </p>
                  <p className="text-muted-foreground">
                    {lastRefresh.toLocaleTimeString("pt-BR", { 
                      timeZone: refreshSettings.timezone,
                      hour: "2-digit", 
                      minute: "2-digit", 
                      second: "2-digit" 
                    })}
                  </p>
                </div>
              </Button>

              {/* Sound Toggle */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSoundEnabled(!soundEnabled)}
                className={cn(
                  "h-10 w-10 p-0",
                  !soundEnabled && "text-muted-foreground"
                )}
                title={soundEnabled ? "Desativar sons" : "Ativar sons"}
              >
                {soundEnabled ? (
                  <Volume2 className="h-5 w-5" />
                ) : (
                  <VolumeX className="h-5 w-5" />
                )}
              </Button>

              {/* Fullscreen Toggle */}
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleFullscreen}
                className="h-10 w-10 p-0"
                title={isFullscreen ? "Sair da tela cheia" : "Tela cheia"}
              >
                <Maximize className="h-5 w-5" />
              </Button>

              {/* Bell indicator */}
              <div className="relative">
                <Bell className={cn("h-6 w-6 text-muted-foreground", hasNewCalls && "text-emergency animate-pulse")} />
                {hasNewCalls && (
                  <span className="absolute -top-1 -right-1 h-3 w-3 bg-emergency rounded-full animate-ping" />
                )}
              </div>

              {/* Clock */}
              <div className="text-right">
                <p className="text-2xl font-bold text-foreground tabular-nums">
                  {now.toLocaleTimeString("pt-BR", { 
                    timeZone: refreshSettings.timezone,
                    hour: "2-digit", 
                    minute: "2-digit", 
                    second: "2-digit" 
                  })}
                </p>
                <p className="text-xs text-muted-foreground">
                  {now.toLocaleDateString("pt-BR", { 
                    timeZone: refreshSettings.timezone,
                    weekday: "long", 
                    day: "numeric", 
                    month: "short" 
                  })}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Stats Bar - Large for TV visibility */}
      <div className="bg-card border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-8">
            <StatBadge label="Total Ativos" value={stats.total} large />
            <StatBadge label="Críticos" value={stats.emergency} variant="emergency" large />
            <StatBadge label="Urgentes" value={stats.urgent} variant="urgent" large />
            <StatBadge label="Rotina" value={stats.routine} variant="routine" large />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-4">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 h-full">
          {/* Active Calls List - Takes most space */}
          <div className="lg:col-span-3 space-y-3 overflow-y-auto">
            <h2 className="text-lg font-semibold text-foreground flex items-center gap-2 sticky top-0 bg-background py-2">
              <Clock className="h-5 w-5" />
              Chamados Ativos
            </h2>
            
            {activeCalls.length === 0 ? (
              <Card className="border-2 border-dashed">
                <CardContent className="py-16 text-center">
                  <CheckCircle2 className="h-16 w-16 text-success mx-auto mb-4" />
                  <p className="text-2xl font-medium text-foreground">Nenhum chamado pendente</p>
                  <p className="text-muted-foreground mt-2">Todos os pacientes foram atendidos</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
                {activeCalls.map((call) => (
                  <CallCard 
                    key={call.id} 
                    call={call} 
                    now={now} 
                    onSeen={markAsSeen} 
                    onAttend={attendCall} 
                    onComplete={completeCall} 
                  />
                ))}
              </div>
            )}
          </div>

          {/* Sidebar - Compact */}
          <div className="space-y-4">
            {/* Recent Completed */}
            <Card>
              <CardHeader className="pb-2 pt-4 px-4">
                <CardTitle className="text-sm flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-success" />
                  Finalizados Recentes
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4">
                {completedCalls.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    Nenhum chamado finalizado
                  </p>
                ) : (
                  <div className="space-y-2">
                    {completedCalls.map((call) => (
                      <div key={call.id} className="flex items-center justify-between text-sm py-2 border-b border-border last:border-0">
                        <div>
                          <span className="font-medium">Leito {call.bedNumber}</span>
                          <span className="text-muted-foreground ml-2 text-xs">{getCallTypeLabel(call.callType)}</span>
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {call.completedAt?.toLocaleTimeString("pt-BR", { 
                            timeZone: refreshSettings.timezone,
                            hour: "2-digit", 
                            minute: "2-digit" 
                          })}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Legend */}
            <Card>
              <CardHeader className="pb-2 pt-4 px-4">
                <CardTitle className="text-sm">Legenda</CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4 space-y-2">
                {Object.entries(PRIORITY_CONFIG).map(([key, { label, className }]) => (
                  <div key={key} className="flex items-center gap-2">
                    <div className={cn("w-4 h-4 rounded-full", className)} />
                    <span className="text-sm text-foreground">{label}</span>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Instructions for TV */}
            <Card className="bg-muted/30">
              <CardContent className="py-4 px-4">
                <p className="text-xs text-muted-foreground text-center">
                  Clique no botão de tela cheia para exibir em TV/Monitor
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

function StatBadge({ 
  label, 
  value, 
  variant, 
  large 
}: { 
  label: string
  value: number
  variant?: "emergency" | "urgent" | "routine"
  large?: boolean
}) {
  const variantClasses = {
    emergency: "text-emergency",
    urgent: "text-urgent",
    routine: "text-routine",
  }
  
  return (
    <div className="flex items-center gap-3">
      <span className={cn(
        "font-bold tabular-nums",
        large ? "text-4xl" : "text-2xl",
        variant ? variantClasses[variant] : "text-foreground"
      )}>
        {value}
      </span>
      <span className={cn(
        "text-muted-foreground",
        large ? "text-base" : "text-sm"
      )}>
        {label}
      </span>
    </div>
  )
}

function CallCard({ 
  call, 
  now, 
  onSeen, 
  onAttend, 
  onComplete 
}: { 
  call: BedCall
  now: Date
  onSeen: (id: string) => void
  onAttend: (id: string) => void
  onComplete: (id: string) => void
}) {
  const Icon = CALL_ICONS[call.callType] || AlertTriangle
  const priorityConfig = PRIORITY_CONFIG[call.priority]
  
  const waitingTime = Math.floor((now.getTime() - call.createdAt.getTime()) / 1000)
  const minutes = Math.floor(waitingTime / 60)
  const seconds = waitingTime % 60

  const isLongWait = minutes >= 5
  const isCritical = call.priority === "emergency"
  const isPending = call.status === "pending"

  return (
    <Card className={cn(
      "transition-all border-l-8",
      call.priority === "emergency" && "border-l-emergency",
      call.priority === "urgent" && "border-l-urgent",
      call.priority === "routine" && "border-l-routine",
      // Efeito piscando para chamados pendentes baseado na prioridade
      isPending && call.priority === "emergency" && "animate-blink-emergency bg-emergency/5",
      isPending && call.priority === "urgent" && "animate-blink-urgent bg-urgent/5",
      isPending && call.priority === "routine" && "animate-blink-routine bg-routine/5"
    )}>
      <CardContent className="p-6">
        {/* Top Row: Info and Timer */}
        <div className="flex items-start justify-between gap-6 mb-6">
          {/* Left: Icon and Info */}
          <div className="flex items-start gap-5">
            <div className={cn("p-5 rounded-2xl shrink-0", priorityConfig.className)}>
              <Icon className="h-12 w-12" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-3 mb-2 flex-wrap">
                <h3 className="text-3xl font-bold text-foreground">Leito {call.bedNumber}</h3>
                <Badge variant="outline" className={cn("text-base px-3 py-1", priorityConfig.className)}>
                  {priorityConfig.label}
                </Badge>
              </div>
              <p className="text-2xl font-semibold text-foreground">{getCallTypeLabel(call.callType)}</p>
            </div>
          </div>

          {/* Right: Timer */}
          <div className={cn(
            "flex items-center gap-3 text-4xl font-mono font-bold shrink-0 bg-muted/50 px-5 py-3 rounded-xl",
            isLongWait ? "text-emergency bg-emergency/10" : isCritical ? "text-emergency bg-emergency/10" : "text-foreground"
          )}>
            <Clock className="h-8 w-8" />
            <span>{String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}</span>
          </div>
        </div>

        {/* Bottom Row: Actions and Status */}
        <div className="flex items-center justify-between gap-4 pt-4 border-t border-border">
          {/* Status indicator */}
          <div className="text-lg text-muted-foreground">
            {call.status === "pending" && "Aguardando atendimento"}
            {call.status === "seen" && "Visualizado pela enfermagem"}
            {call.status === "attending" && "Em atendimento"}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            {call.status === "pending" && (
              <>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => onSeen(call.id)}
                  className="h-14 px-6 text-lg"
                >
                  <Eye className="h-5 w-5 mr-2" />
                  Visualizar
                </Button>
                <Button
                  size="lg"
                  onClick={() => onAttend(call.id)}
                  className="h-14 px-8 text-lg bg-primary text-primary-foreground"
                >
                  <Play className="h-5 w-5 mr-2" />
                  Atender
                </Button>
              </>
            )}
            {call.status === "seen" && (
              <Button
                size="lg"
                onClick={() => onAttend(call.id)}
                className="h-14 px-8 text-lg bg-primary text-primary-foreground"
              >
                <Play className="h-5 w-5 mr-2" />
                Atender
              </Button>
            )}
            {call.status === "attending" && (
              <Button
                size="lg"
                onClick={() => onComplete(call.id)}
                className="h-14 px-8 text-lg bg-success text-success-foreground"
              >
                <CheckCircle2 className="h-5 w-5 mr-2" />
                Finalizar
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
