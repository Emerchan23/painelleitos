-- ============================================
-- SISTEMA DE CHAMADOS HOSPITALARES
-- Script de criação do banco de dados MariaDB
-- ============================================

-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS hospital_system
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE hospital_system;

-- ============================================
-- TABELA: admin_users (Usuários Administrativos)
-- ============================================
CREATE TABLE IF NOT EXISTS admin_users (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email)
) ENGINE=InnoDB;

-- Inserir usuário admin padrão (senha: admin123)
-- A senha deve ser hasheada em produção com bcrypt
INSERT INTO admin_users (id, name, email, password) VALUES
('admin1', 'Administrador', 'admin@hospital.com', '$2b$10$rOzJqQZQZQZQZQZQZQZQZOeJqQZQZQZQZQZQZQZQZQZQZQZQZQZQZ')
ON DUPLICATE KEY UPDATE name = name;

-- ============================================
-- TABELA: wards (Alas Hospitalares)
-- ============================================
CREATE TABLE IF NOT EXISTS wards (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Inserir alas padrão
INSERT INTO wards (id, name, description) VALUES
('ward-uti', 'UTI', 'Unidade de Terapia Intensiva'),
('ward-enfermaria', 'Enfermaria', 'Enfermaria Geral'),
('ward-pediatria', 'Pediatria', 'Ala Pediátrica'),
('ward-maternidade', 'Maternidade', 'Ala de Maternidade'),
('ward-emergencia', 'Emergência', 'Pronto Socorro')
ON DUPLICATE KEY UPDATE description = VALUES(description);

-- ============================================
-- TABELA: beds (Leitos)
-- ============================================
CREATE TABLE IF NOT EXISTS beds (
    id VARCHAR(36) PRIMARY KEY,
    number VARCHAR(20) NOT NULL,
    ward VARCHAR(100) NOT NULL,
    room VARCHAR(50) NOT NULL,
    status ENUM('available', 'occupied', 'maintenance', 'reserved') DEFAULT 'available',
    patient_name VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_bed_number (number),
    INDEX idx_ward (ward),
    INDEX idx_status (status),
    FOREIGN KEY (ward) REFERENCES wards(name) ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Inserir leitos de demonstração
INSERT INTO beds (id, number, ward, room, status, patient_name) VALUES
('bed-1', '101', 'UTI', 'A1', 'occupied', 'Maria Silva'),
('bed-2', '102', 'UTI', 'A1', 'occupied', 'João Santos'),
('bed-3', '103', 'UTI', 'A2', 'available', NULL),
('bed-4', '201', 'Enfermaria', 'B1', 'occupied', 'Ana Oliveira'),
('bed-5', '202', 'Enfermaria', 'B1', 'occupied', 'Pedro Costa'),
('bed-6', '203', 'Enfermaria', 'B2', 'maintenance', NULL),
('bed-7', '301', 'Pediatria', 'C1', 'occupied', 'Lucas Mendes'),
('bed-8', '302', 'Pediatria', 'C1', 'available', NULL),
('bed-9', '401', 'Maternidade', 'D1', 'occupied', 'Carla Souza'),
('bed-10', '501', 'Emergência', 'E1', 'occupied', 'Roberto Lima'),
('bed-11', '502', 'Emergência', 'E1', 'reserved', NULL),
('bed-12', '503', 'Emergência', 'E2', 'available', NULL)
ON DUPLICATE KEY UPDATE room = VALUES(room);

-- ============================================
-- TABELA: call_types (Tipos de Chamado)
-- ============================================
CREATE TABLE IF NOT EXISTS call_types (
    id VARCHAR(36) PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    priority ENUM('emergency', 'urgent', 'routine') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Inserir tipos de chamado
INSERT INTO call_types (id, code, name, priority) VALUES
('type-emergency', 'emergency', 'Emergência', 'emergency'),
('type-pain', 'pain', 'Dor', 'urgent'),
('type-hygiene', 'hygiene', 'Higiene', 'routine'),
('type-water', 'water', 'Água', 'routine'),
('type-bed', 'bed', 'Ajustar Leito', 'routine')
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- ============================================
-- TABELA: calls (Chamados)
-- ============================================
CREATE TABLE IF NOT EXISTS calls (
    id VARCHAR(36) PRIMARY KEY,
    bed_id VARCHAR(36) NOT NULL,
    bed_number VARCHAR(20) NOT NULL,
    patient_name VARCHAR(255) NOT NULL,
    call_type VARCHAR(50) NOT NULL,
    priority ENUM('emergency', 'urgent', 'routine') NOT NULL,
    status ENUM('pending', 'seen', 'attending', 'completed') DEFAULT 'pending',
    ward VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    seen_at TIMESTAMP NULL,
    attending_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL,
    INDEX idx_status (status),
    INDEX idx_priority (priority),
    INDEX idx_bed_number (bed_number),
    INDEX idx_ward (ward),
    INDEX idx_created_at (created_at),
    INDEX idx_status_priority (status, priority),
    FOREIGN KEY (bed_id) REFERENCES beds(id) ON DELETE CASCADE,
    FOREIGN KEY (call_type) REFERENCES call_types(code) ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- TABELA: sound_settings (Configurações de Som)
-- ============================================
CREATE TABLE IF NOT EXISTS sound_settings (
    id VARCHAR(36) PRIMARY KEY DEFAULT 'default',
    enabled BOOLEAN DEFAULT TRUE,
    volume DECIMAL(3, 2) DEFAULT 0.80,
    emergency_sound ENUM('beep', 'alarm', 'chime', 'siren', 'bell') DEFAULT 'siren',
    urgent_sound ENUM('beep', 'alarm', 'chime', 'siren', 'bell') DEFAULT 'alarm',
    routine_sound ENUM('beep', 'alarm', 'chime', 'siren', 'bell') DEFAULT 'beep',
    repeat_interval_seconds INT DEFAULT 20,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Inserir configurações padrão
INSERT INTO sound_settings (id, enabled, volume, emergency_sound, urgent_sound, routine_sound, repeat_interval_seconds)
VALUES ('default', TRUE, 0.80, 'siren', 'alarm', 'beep', 20)
ON DUPLICATE KEY UPDATE id = id;

-- ============================================
-- TABELA: refresh_settings (Configurações de Atualização)
-- ============================================
CREATE TABLE IF NOT EXISTS refresh_settings (
    id VARCHAR(36) PRIMARY KEY DEFAULT 'default',
    enabled BOOLEAN DEFAULT TRUE,
    interval_seconds INT DEFAULT 30,
    timezone VARCHAR(50) DEFAULT 'America/Sao_Paulo',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Inserir configurações padrão
INSERT INTO refresh_settings (id, enabled, interval_seconds, timezone)
VALUES ('default', TRUE, 30, 'America/Sao_Paulo')
ON DUPLICATE KEY UPDATE id = id;

-- ============================================
-- TABELA: sessions (Sessões de Usuário)
-- ============================================
CREATE TABLE IF NOT EXISTS sessions (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    token VARCHAR(255) NOT NULL UNIQUE,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_token (token),
    INDEX idx_user_id (user_id),
    INDEX idx_expires_at (expires_at),
    FOREIGN KEY (user_id) REFERENCES admin_users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- TABELA: call_history (Histórico de Chamados)
-- ============================================
CREATE TABLE IF NOT EXISTS call_history (
    id VARCHAR(36) PRIMARY KEY,
    call_id VARCHAR(36) NOT NULL,
    action ENUM('created', 'seen', 'attending', 'completed') NOT NULL,
    user_id VARCHAR(36),
    details TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_call_id (call_id),
    INDEX idx_action (action),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- ============================================
-- VIEWS
-- ============================================

-- View: Chamados ativos com informações do leito
CREATE OR REPLACE VIEW v_active_calls AS
SELECT 
    c.id,
    c.bed_number,
    c.patient_name,
    c.call_type,
    c.priority,
    c.status,
    c.ward,
    c.created_at,
    c.seen_at,
    c.attending_at,
    b.room,
    TIMESTAMPDIFF(SECOND, c.created_at, NOW()) as waiting_seconds
FROM calls c
LEFT JOIN beds b ON c.bed_id = b.id
WHERE c.status != 'completed'
ORDER BY 
    FIELD(c.priority, 'emergency', 'urgent', 'routine'),
    c.created_at ASC;

-- View: Estatísticas de SLA por ala
CREATE OR REPLACE VIEW v_sla_by_ward AS
SELECT 
    ward,
    COUNT(*) as total_calls,
    AVG(TIMESTAMPDIFF(SECOND, created_at, completed_at)) as avg_response_seconds,
    MIN(TIMESTAMPDIFF(SECOND, created_at, completed_at)) as min_response_seconds,
    MAX(TIMESTAMPDIFF(SECOND, created_at, completed_at)) as max_response_seconds
FROM calls
WHERE status = 'completed' AND completed_at IS NOT NULL AND ward IS NOT NULL
GROUP BY ward;

-- View: Resumo de leitos por ala
CREATE OR REPLACE VIEW v_beds_summary AS
SELECT 
    ward,
    COUNT(*) as total_beds,
    SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available,
    SUM(CASE WHEN status = 'occupied' THEN 1 ELSE 0 END) as occupied,
    SUM(CASE WHEN status = 'maintenance' THEN 1 ELSE 0 END) as maintenance,
    SUM(CASE WHEN status = 'reserved' THEN 1 ELSE 0 END) as reserved
FROM beds
GROUP BY ward;

-- ============================================
-- TRIGGERS
-- ============================================

-- Trigger: Registrar histórico quando chamado é criado
DELIMITER //
CREATE TRIGGER IF NOT EXISTS tr_call_created
AFTER INSERT ON calls
FOR EACH ROW
BEGIN
    INSERT INTO call_history (id, call_id, action, details)
    VALUES (UUID(), NEW.id, 'created', CONCAT('Chamado criado - Tipo: ', NEW.call_type, ', Prioridade: ', NEW.priority));
END//
DELIMITER ;

-- Trigger: Registrar histórico quando status do chamado muda
DELIMITER //
CREATE TRIGGER IF NOT EXISTS tr_call_status_changed
AFTER UPDATE ON calls
FOR EACH ROW
BEGIN
    IF OLD.status != NEW.status THEN
        INSERT INTO call_history (id, call_id, action, details)
        VALUES (UUID(), NEW.id, NEW.status, CONCAT('Status alterado de ', OLD.status, ' para ', NEW.status));
    END IF;
END//
DELIMITER ;

-- ============================================
-- STORED PROCEDURES
-- ============================================

-- Procedure: Criar novo chamado
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS sp_create_call(
    IN p_bed_number VARCHAR(20),
    IN p_patient_name VARCHAR(255),
    IN p_call_type VARCHAR(50),
    IN p_ward VARCHAR(100)
)
BEGIN
    DECLARE v_id VARCHAR(36);
    DECLARE v_bed_id VARCHAR(36);
    DECLARE v_priority VARCHAR(20);
    
    SET v_id = UUID();
    
    -- Buscar ID do leito
    SELECT id INTO v_bed_id FROM beds WHERE number = p_bed_number LIMIT 1;
    
    -- Buscar prioridade do tipo de chamado
    SELECT priority INTO v_priority FROM call_types WHERE code = p_call_type LIMIT 1;
    
    -- Se não encontrar prioridade, usar 'routine'
    IF v_priority IS NULL THEN
        SET v_priority = 'routine';
    END IF;
    
    -- Criar o chamado
    INSERT INTO calls (id, bed_id, bed_number, patient_name, call_type, priority, status, ward)
    VALUES (v_id, v_bed_id, p_bed_number, p_patient_name, p_call_type, v_priority, 'pending', p_ward);
    
    SELECT v_id as id;
END//
DELIMITER ;

-- Procedure: Atualizar status do chamado
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS sp_update_call_status(
    IN p_call_id VARCHAR(36),
    IN p_status VARCHAR(20)
)
BEGIN
    UPDATE calls 
    SET 
        status = p_status,
        seen_at = CASE WHEN p_status = 'seen' AND seen_at IS NULL THEN NOW() ELSE seen_at END,
        attending_at = CASE WHEN p_status = 'attending' AND attending_at IS NULL THEN NOW() ELSE attending_at END,
        completed_at = CASE WHEN p_status = 'completed' AND completed_at IS NULL THEN NOW() ELSE completed_at END
    WHERE id = p_call_id;
    
    SELECT * FROM calls WHERE id = p_call_id;
END//
DELIMITER ;

-- Procedure: Limpar sessões expiradas
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS sp_cleanup_expired_sessions()
BEGIN
    DELETE FROM sessions WHERE expires_at < NOW();
END//
DELIMITER ;

-- ============================================
-- EVENTOS (Limpeza automática)
-- ============================================

-- Habilitar event scheduler
SET GLOBAL event_scheduler = ON;

-- Evento: Limpar sessões expiradas a cada hora
CREATE EVENT IF NOT EXISTS ev_cleanup_sessions
ON SCHEDULE EVERY 1 HOUR
DO CALL sp_cleanup_expired_sessions();

-- Evento: Arquivar chamados antigos (mais de 30 dias)
-- Comentado por padrão - descomentar se necessário
-- CREATE EVENT IF NOT EXISTS ev_archive_old_calls
-- ON SCHEDULE EVERY 1 DAY
-- DO
-- BEGIN
--     DELETE FROM calls WHERE status = 'completed' AND completed_at < DATE_SUB(NOW(), INTERVAL 30 DAY);
-- END;

-- ============================================
-- ÍNDICES ADICIONAIS PARA PERFORMANCE
-- ============================================
CREATE INDEX IF NOT EXISTS idx_calls_composite ON calls (status, priority, created_at);
CREATE INDEX IF NOT EXISTS idx_beds_ward_status ON beds (ward, status);

-- ============================================
-- PERMISSÕES (ajustar conforme necessário)
-- ============================================
-- GRANT ALL PRIVILEGES ON hospital_system.* TO 'hospital_app'@'localhost' IDENTIFIED BY 'senha_segura';
-- FLUSH PRIVILEGES;

SELECT 'Schema do banco de dados criado com sucesso!' as message;
