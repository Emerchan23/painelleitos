-- Script para criar usuário admin com senha hasheada
-- Senha: admin123
-- Hash bcrypt gerado: $2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy

USE hospital_system;

-- Limpar usuário admin existente (opcional)
DELETE FROM sessions WHERE user_id = 'admin1';
DELETE FROM admin_users WHERE id = 'admin1';

-- Inserir novo usuário admin com senha hasheada
INSERT INTO admin_users (id, name, email, password, created_at) VALUES
('admin1', 'Administrador', 'admin@hospital.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', NOW());

SELECT 'Usuário admin criado com sucesso!' as message;
SELECT 'Email: admin@hospital.com' as credenciais;
SELECT 'Senha: admin123' as senha;
