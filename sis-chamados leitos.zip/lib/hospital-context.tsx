"use client"

import React, { createContext, useContext, useState, useCallback, useEffect, useRef } from "react"

export type CallPriority = "emergency" | "urgent" | "routine"
export type CallStatus = "pending" | "seen" | "attending" | "completed"

export type CallType = "emergency" | "pain" | "hygiene" | "water" | "bed"

export type BedStatus = "available" | "occupied" | "maintenance" | "reserved"
export type WardType = "UTI" | "Enfermaria" | "Pediatria" | "Maternidade" | "Emergência"

export type AlertSoundType = "beep" | "alarm" | "chime" | "siren" | "bell"

export interface AdminUser {
  id: string
  name: string
  email: string
  password: string
  createdAt: Date
}

export interface SoundSettings {
  enabled: boolean
  volume: number // 0-1
  emergencySound: AlertSoundType
  urgentSound: AlertSoundType
  routineSound: AlertSoundType
  repeatIntervalSeconds: number // 10-120 seconds - interval to repeat sound when not attended
}

export type TimezoneOption = "America/Sao_Paulo" | "America/Manaus" | "America/Bahia" | "America/Fortaleza" | "America/Recife" | "America/Cuiaba" | "America/Porto_Velho" | "America/Rio_Branco"

export const TIMEZONE_LABELS: Record<TimezoneOption, string> = {
  "America/Sao_Paulo": "Brasília (GMT-3)",
  "America/Bahia": "Bahia (GMT-3)",
  "America/Fortaleza": "Fortaleza (GMT-3)",
  "America/Recife": "Recife (GMT-3)",
  "America/Cuiaba": "Cuiabá (GMT-4)",
  "America/Manaus": "Manaus (GMT-4)",
  "America/Porto_Velho": "Porto Velho (GMT-4)",
  "America/Rio_Branco": "Rio Branco (GMT-5)",
}

export interface RefreshSettings {
  enabled: boolean
  intervalSeconds: number // 10-120 seconds
  timezone: TimezoneOption
}

export interface Bed {
  id: string
  number: string
  ward: WardType
  room: string
  status: BedStatus
  patientName?: string
  createdAt: Date
  updatedAt: Date
}

export interface BedCall {
  id: string
  bedNumber: string
  patientName: string
  callType: CallType
  priority: CallPriority
  status: CallStatus
  createdAt: Date
  seenAt?: Date
  attendingAt?: Date
  completedAt?: Date
  ward?: WardType
}

interface HospitalContextType {
  // Calls
  calls: BedCall[]
  createCall: (bedNumber: string, patientName: string, callType: CallType, ward?: WardType) => void
  markAsSeen: (callId: string) => void
  attendCall: (callId: string) => void
  completeCall: (callId: string) => void
  getCallsForBed: (bedNumber: string) => BedCall[]
  hasNewCalls: boolean
  setHasNewCalls: (value: boolean) => void
  
  // Beds Management
  beds: Bed[]
  addBed: (bed: Omit<Bed, "id" | "createdAt" | "updatedAt">) => void
  updateBed: (id: string, updates: Partial<Omit<Bed, "id" | "createdAt">>) => void
  deleteBed: (id: string) => void
  getBedsByWard: (ward: WardType) => Bed[]
  getOccupiedBeds: () => Bed[]
  
  // SLA Stats
  getSLAByWard: () => Record<WardType, { avgTime: number; count: number }>

  // Authentication
  currentUser: AdminUser | null
  adminUsers: AdminUser[]
  login: (email: string, password: string) => boolean
  logout: () => void
  addAdminUser: (user: Omit<AdminUser, "id" | "createdAt">) => void
  deleteAdminUser: (id: string) => void
  isAuthenticated: boolean

  // Sound Settings
  soundSettings: SoundSettings
  updateSoundSettings: (settings: Partial<SoundSettings>) => void
  playAlertSound: (priority: CallPriority) => void

  // Refresh Settings
  refreshSettings: RefreshSettings
  updateRefreshSettings: (settings: Partial<RefreshSettings>) => void
}

const HospitalContext = createContext<HospitalContextType | undefined>(undefined)

const CALL_TYPE_PRIORITY: Record<CallType, CallPriority> = {
  emergency: "emergency",
  pain: "urgent",
  hygiene: "routine",
  water: "routine",
  bed: "routine",
}

const CALL_TYPE_LABELS: Record<CallType, string> = {
  emergency: "Emergência",
  pain: "Dor",
  hygiene: "Higiene",
  water: "Água",
  bed: "Ajustar Leito",
}

export const ALERT_SOUND_LABELS: Record<AlertSoundType, string> = {
  beep: "Beep Duplo",
  alarm: "Alarme Hospitalar",
  chime: "Sino",
  siren: "Sirene",
  bell: "Campainha",
}

export function getCallTypeLabel(type: CallType): string {
  return CALL_TYPE_LABELS[type]
}

// Default beds for demonstration
const DEFAULT_BEDS: Bed[] = [
  { id: "1", number: "101", ward: "UTI", room: "A1", status: "occupied", patientName: "Maria Silva", createdAt: new Date(), updatedAt: new Date() },
  { id: "2", number: "102", ward: "UTI", room: "A1", status: "occupied", patientName: "João Santos", createdAt: new Date(), updatedAt: new Date() },
  { id: "3", number: "103", ward: "UTI", room: "A2", status: "available", createdAt: new Date(), updatedAt: new Date() },
  { id: "4", number: "201", ward: "Enfermaria", room: "B1", status: "occupied", patientName: "Ana Oliveira", createdAt: new Date(), updatedAt: new Date() },
  { id: "5", number: "202", ward: "Enfermaria", room: "B1", status: "occupied", patientName: "Pedro Costa", createdAt: new Date(), updatedAt: new Date() },
  { id: "6", number: "203", ward: "Enfermaria", room: "B2", status: "maintenance", createdAt: new Date(), updatedAt: new Date() },
  { id: "7", number: "301", ward: "Pediatria", room: "C1", status: "occupied", patientName: "Lucas Mendes", createdAt: new Date(), updatedAt: new Date() },
  { id: "8", number: "302", ward: "Pediatria", room: "C1", status: "available", createdAt: new Date(), updatedAt: new Date() },
  { id: "9", number: "401", ward: "Maternidade", room: "D1", status: "occupied", patientName: "Carla Souza", createdAt: new Date(), updatedAt: new Date() },
  { id: "10", number: "501", ward: "Emergência", room: "E1", status: "occupied", patientName: "Roberto Lima", createdAt: new Date(), updatedAt: new Date() },
  { id: "11", number: "502", ward: "Emergência", room: "E1", status: "reserved", createdAt: new Date(), updatedAt: new Date() },
  { id: "12", number: "503", ward: "Emergência", room: "E2", status: "available", createdAt: new Date(), updatedAt: new Date() },
]

// Demo completed calls for SLA calculation
const DEMO_COMPLETED_CALLS: BedCall[] = [
  { id: "demo1", bedNumber: "101", patientName: "Maria Silva", callType: "water", priority: "routine", status: "completed", ward: "UTI", createdAt: new Date(Date.now() - 1800000), completedAt: new Date(Date.now() - 1500000) },
  { id: "demo2", bedNumber: "201", patientName: "Ana Oliveira", callType: "pain", priority: "urgent", status: "completed", ward: "Enfermaria", createdAt: new Date(Date.now() - 3600000), completedAt: new Date(Date.now() - 3000000) },
  { id: "demo3", bedNumber: "301", patientName: "Lucas Mendes", callType: "hygiene", priority: "routine", status: "completed", ward: "Pediatria", createdAt: new Date(Date.now() - 7200000), completedAt: new Date(Date.now() - 6600000) },
  { id: "demo4", bedNumber: "501", patientName: "Roberto Lima", callType: "emergency", priority: "emergency", status: "completed", ward: "Emergência", createdAt: new Date(Date.now() - 900000), completedAt: new Date(Date.now() - 600000) },
  { id: "demo5", bedNumber: "102", patientName: "João Santos", callType: "bed", priority: "routine", status: "completed", ward: "UTI", createdAt: new Date(Date.now() - 5400000), completedAt: new Date(Date.now() - 4800000) },
  { id: "demo6", bedNumber: "202", patientName: "Pedro Costa", callType: "water", priority: "routine", status: "completed", ward: "Enfermaria", createdAt: new Date(Date.now() - 2700000), completedAt: new Date(Date.now() - 2100000) },
]

// Default admin user
const DEFAULT_ADMIN_USERS: AdminUser[] = [
  { id: "admin1", name: "Administrador", email: "admin@hospital.com", password: "admin123", createdAt: new Date() },
]

const DEFAULT_SOUND_SETTINGS: SoundSettings = {
  enabled: true,
  volume: 0.8,
  emergencySound: "siren",
  urgentSound: "alarm",
  routineSound: "beep",
  repeatIntervalSeconds: 20, // Default 20 seconds
}

const DEFAULT_REFRESH_SETTINGS: RefreshSettings = {
  enabled: true,
  intervalSeconds: 30, // Default 30 seconds
  timezone: "America/Sao_Paulo", // Brasília timezone
}

export function HospitalProvider({ children }: { children: React.ReactNode }) {
  const [calls, setCalls] = useState<BedCall[]>(DEMO_COMPLETED_CALLS)
  const [beds, setBeds] = useState<Bed[]>(DEFAULT_BEDS)
  const [hasNewCalls, setHasNewCalls] = useState(false)
  const [currentUser, setCurrentUser] = useState<AdminUser | null>(null)
  const [adminUsers, setAdminUsers] = useState<AdminUser[]>(DEFAULT_ADMIN_USERS)
  const [soundSettings, setSoundSettings] = useState<SoundSettings>(DEFAULT_SOUND_SETTINGS)
  const [refreshSettings, setRefreshSettings] = useState<RefreshSettings>(DEFAULT_REFRESH_SETTINGS)
  const audioContextRef = useRef<AudioContext | null>(null)

  // Initialize audio context on first user interaction
  useEffect(() => {
    const initAudioContext = () => {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)()
      }
    }
    
    window.addEventListener('click', initAudioContext, { once: true })
    window.addEventListener('touchstart', initAudioContext, { once: true })
    
    return () => {
      window.removeEventListener('click', initAudioContext)
      window.removeEventListener('touchstart', initAudioContext)
    }
  }, [])

  const playAlertSound = useCallback((priority: CallPriority) => {
    if (!soundSettings.enabled) return

    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)()
    }
    
    const soundType = priority === "emergency" 
      ? soundSettings.emergencySound 
      : priority === "urgent" 
        ? soundSettings.urgentSound 
        : soundSettings.routineSound

    try {
      const ctx = audioContextRef.current
      const volume = soundSettings.volume
      
      // Resume audio context if suspended (required for some browsers)
      if (ctx.state === 'suspended') {
        ctx.resume()
      }

      // Helper function to play a tone
      const playTone = (frequency: number, duration: number, type: OscillatorType, vol: number, delay: number = 0) => {
        const startTime = ctx.currentTime + delay
        const osc = ctx.createOscillator()
        const gain = ctx.createGain()
        osc.connect(gain)
        gain.connect(ctx.destination)
        osc.frequency.value = frequency
        osc.type = type
        gain.gain.setValueAtTime(vol, startTime)
        gain.gain.exponentialRampToValueAtTime(0.01, startTime + duration)
        osc.start(startTime)
        osc.stop(startTime + duration)
      }

      // Helper function to play a siren sweep
      const playSiren = (startFreq: number, endFreq: number, duration: number, vol: number, delay: number = 0) => {
        const startTime = ctx.currentTime + delay
        const osc = ctx.createOscillator()
        const gain = ctx.createGain()
        osc.connect(gain)
        gain.connect(ctx.destination)
        osc.type = 'sawtooth'
        osc.frequency.setValueAtTime(startFreq, startTime)
        osc.frequency.linearRampToValueAtTime(endFreq, startTime + duration / 2)
        osc.frequency.linearRampToValueAtTime(startFreq, startTime + duration)
        gain.gain.setValueAtTime(vol, startTime)
        gain.gain.exponentialRampToValueAtTime(0.01, startTime + duration)
        osc.start(startTime)
        osc.stop(startTime + duration)
      }

      switch (soundType) {
        case "beep":
          // Double beep
          playTone(880, 0.3, 'sine', volume * 0.3, 0)
          playTone(880, 0.3, 'sine', volume * 0.3, 0.2)
          break

        case "alarm":
          // Hospital alarm - alternating tones
          for (let i = 0; i < 6; i++) {
            const freq = i % 2 === 0 ? 800 : 1000
            playTone(freq, 0.15, 'square', volume * 0.4, i * 0.18)
          }
          break

        case "chime":
          // Pleasant chime - C5, E5, G5 chord
          const chimeFreqs = [523, 659, 784]
          chimeFreqs.forEach((freq, i) => {
            playTone(freq, 0.4, 'sine', volume * 0.25, i * 0.15)
          })
          break

        case "siren":
          // Urgent siren - sweeping frequency
          for (let i = 0; i < 3; i++) {
            playSiren(600, 1200, 0.5, volume * 0.5, i * 0.6)
          }
          break

        case "bell":
          // Bell ring - high frequency with decay
          for (let i = 0; i < 3; i++) {
            playTone(1047, 0.5, 'sine', volume * 0.35, i * 0.4)
          }
          break
      }
    } catch {
      // Audio failed silently
    }
  }, [soundSettings])

  const createCall = useCallback((bedNumber: string, patientName: string, callType: CallType, ward?: WardType) => {
    const priority = CALL_TYPE_PRIORITY[callType]
    const newCall: BedCall = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      bedNumber,
      patientName,
      callType,
      priority,
      status: "pending",
      createdAt: new Date(),
      ward,
    }
    setCalls((prev) => [...prev, newCall])
    setHasNewCalls(true)
    playAlertSound(priority)
  }, [playAlertSound])

  const markAsSeen = useCallback((callId: string) => {
    setCalls((prev) =>
      prev.map((call) =>
        call.id === callId && call.status === "pending"
          ? { ...call, status: "seen" as CallStatus, seenAt: new Date() }
          : call
      )
    )
  }, [])

  const attendCall = useCallback((callId: string) => {
    setCalls((prev) =>
      prev.map((call) =>
        call.id === callId && (call.status === "pending" || call.status === "seen")
          ? { ...call, status: "attending" as CallStatus, attendingAt: new Date() }
          : call
      )
    )
  }, [])

  const completeCall = useCallback((callId: string) => {
    setCalls((prev) =>
      prev.map((call) =>
        call.id === callId
          ? { ...call, status: "completed" as CallStatus, completedAt: new Date() }
          : call
      )
    )
  }, [])

  const getCallsForBed = useCallback(
    (bedNumber: string) => {
      return calls.filter((call) => call.bedNumber === bedNumber && call.status !== "completed")
    },
    [calls]
  )

  // Bed Management Functions
  const addBed = useCallback((bedData: Omit<Bed, "id" | "createdAt" | "updatedAt">) => {
    const newBed: Bed = {
      ...bedData,
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    setBeds((prev) => [...prev, newBed])
  }, [])

  const updateBed = useCallback((id: string, updates: Partial<Omit<Bed, "id" | "createdAt">>) => {
    setBeds((prev) =>
      prev.map((bed) =>
        bed.id === id
          ? { ...bed, ...updates, updatedAt: new Date() }
          : bed
      )
    )
  }, [])

  const deleteBed = useCallback((id: string) => {
    setBeds((prev) => prev.filter((bed) => bed.id !== id))
  }, [])

  const getBedsByWard = useCallback((ward: WardType) => {
    return beds.filter((bed) => bed.ward === ward)
  }, [beds])

  const getOccupiedBeds = useCallback(() => {
    return beds.filter((bed) => bed.status === "occupied")
  }, [beds])

  // SLA Calculation
  const getSLAByWard = useCallback(() => {
    const completedCalls = calls.filter((call) => call.status === "completed" && call.completedAt && call.ward)
    
    const wardStats: Record<WardType, { totalTime: number; count: number }> = {
      UTI: { totalTime: 0, count: 0 },
      Enfermaria: { totalTime: 0, count: 0 },
      Pediatria: { totalTime: 0, count: 0 },
      Maternidade: { totalTime: 0, count: 0 },
      Emergência: { totalTime: 0, count: 0 },
    }
    
    completedCalls.forEach((call) => {
      if (call.ward && call.completedAt) {
        const responseTime = call.completedAt.getTime() - call.createdAt.getTime()
        wardStats[call.ward].totalTime += responseTime
        wardStats[call.ward].count += 1
      }
    })
    
    const result: Record<WardType, { avgTime: number; count: number }> = {} as Record<WardType, { avgTime: number; count: number }>
    
    Object.keys(wardStats).forEach((ward) => {
      const w = ward as WardType
      result[w] = {
        avgTime: wardStats[w].count > 0 ? wardStats[w].totalTime / wardStats[w].count : 0,
        count: wardStats[w].count,
      }
    })
    
    return result
  }, [calls])

  // Authentication
  const login = useCallback((email: string, password: string) => {
    const user = adminUsers.find((u) => u.email === email && u.password === password)
    if (user) {
      setCurrentUser(user)
      return true
    }
    return false
  }, [adminUsers])

  const logout = useCallback(() => {
    setCurrentUser(null)
  }, [])

  const addAdminUser = useCallback((userData: Omit<AdminUser, "id" | "createdAt">) => {
    const newUser: AdminUser = {
      ...userData,
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date(),
    }
    setAdminUsers((prev) => [...prev, newUser])
  }, [])

  const deleteAdminUser = useCallback((id: string) => {
    setAdminUsers((prev) => prev.filter((user) => user.id !== id))
  }, [])

  const updateSoundSettings = useCallback((settings: Partial<SoundSettings>) => {
    setSoundSettings((prev) => ({ ...prev, ...settings }))
  }, [])

  const updateRefreshSettings = useCallback((settings: Partial<RefreshSettings>) => {
    setRefreshSettings((prev) => ({ ...prev, ...settings }))
  }, [])

  return (
    <HospitalContext.Provider
      value={{
        calls,
        createCall,
        markAsSeen,
        attendCall,
        completeCall,
        getCallsForBed,
        hasNewCalls,
        setHasNewCalls,
        beds,
        addBed,
        updateBed,
        deleteBed,
        getBedsByWard,
        getOccupiedBeds,
        getSLAByWard,
        currentUser,
        adminUsers,
        login,
        logout,
        addAdminUser,
        deleteAdminUser,
        isAuthenticated: !!currentUser,
        soundSettings,
        updateSoundSettings,
        playAlertSound,
        refreshSettings,
        updateRefreshSettings,
      }}
    >
      {children}
    </HospitalContext.Provider>
  )
}

export function useHospital() {
  const context = useContext(HospitalContext)
  if (context === undefined) {
    throw new Error("useHospital must be used within a HospitalProvider")
  }
  return context
}
